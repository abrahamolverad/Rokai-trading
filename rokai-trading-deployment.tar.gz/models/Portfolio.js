const mongoose = require('mongoose');

const PortfolioSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  balance: {
    type: Number,
    default: 100000
  },
  equity: {
    type: Number,
    default: 100000
  },
  positions: [{
    symbol: {
      type: String,
      required: true,
      trim: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 0
    },
    entryPrice: {
      type: Number,
      required: true,
      min: 0
    },
    currentPrice: {
      type: Number,
      required: true,
      min: 0
    },
    value: {
      type: Number,
      required: true
    },
    unrealizedPL: {
      type: Number,
      default: 0
    },
    unrealizedPLPercent: {
      type: Number,
      default: 0
    }
  }],
  performance: {
    totalReturn: {
      type: Number,
      default: 0
    },
    totalReturnPercent: {
      type: Number,
      default: 0
    },
    dailyReturn: {
      type: Number,
      default: 0
    },
    dailyReturnPercent: {
      type: Number,
      default: 0
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Portfolio', PortfolioSchema);
