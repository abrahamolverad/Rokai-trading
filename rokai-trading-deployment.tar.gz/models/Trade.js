const mongoose = require('mongoose');

const TradeSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  portfolioId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Portfolio',
    required: true
  },
  symbol: {
    type: String,
    required: true,
    trim: true
  },
  type: {
    type: String,
    enum: ['market', 'limit', 'stop', 'stop_limit'],
    default: 'market'
  },
  side: {
    type: String,
    enum: ['buy', 'sell'],
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 0
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  stopPrice: {
    type: Number,
    min: 0
  },
  limitPrice: {
    type: Number,
    min: 0
  },
  status: {
    type: String,
    enum: ['open', 'filled', 'canceled', 'rejected', 'expired'],
    default: 'open'
  },
  executedPrice: {
    type: Number,
    min: 0
  },
  executedQuantity: {
    type: Number,
    min: 0
  },
  commission: {
    type: Number,
    default: 0
  },
  realizedPL: {
    type: Number
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  executedAt: {
    type: Date
  }
});

module.exports = mongoose.model('Trade', TradeSchema);
