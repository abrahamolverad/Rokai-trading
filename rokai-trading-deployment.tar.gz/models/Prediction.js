const mongoose = require('mongoose');

const PredictionSchema = new mongoose.Schema({
  symbol: {
    type: String,
    required: true,
    trim: true
  },
  signal: {
    type: String,
    enum: ['buy', 'sell', 'hold'],
    required: true
  },
  currentPrice: {
    type: Number,
    required: true,
    min: 0
  },
  targetPrice: {
    type: Number,
    required: true,
    min: 0
  },
  potential: {
    type: Number,
    required: true
  },
  timeframe: {
    type: String,
    required: true
  },
  confidence: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  model: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'expired', 'evaluated'],
    default: 'active'
  },
  actualOutcome: {
    price: {
      type: Number,
      min: 0
    },
    correct: {
      type: Boolean
    },
    returnPercent: {
      type: Number
    },
    evaluatedAt: {
      type: Date
    }
  }
});

module.exports = mongoose.model('Prediction', PredictionSchema);
