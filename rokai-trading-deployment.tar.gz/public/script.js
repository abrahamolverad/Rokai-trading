// Main JavaScript for Hawk-AITrading platform

// Theme toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
    } else if (savedTheme === 'light') {
        document.body.classList.remove('dark-mode');
    }
    
    // Theme toggle button
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            const currentTheme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
            localStorage.setItem('theme', currentTheme);
            
            // Update icon
            const themeIcon = this.querySelector('i');
            if (themeIcon) {
                if (currentTheme === 'dark') {
                    themeIcon.className = 'fas fa-sun';
                } else {
                    themeIcon.className = 'fas fa-moon';
                }
            }
        });
    }
    
    // Check for authentication
    checkAuth();
    
    // Initialize API client
    initApiClient();
    
    // Load data if on dashboard
    if (window.location.pathname === '/' || window.location.pathname.includes('index.html')) {
        loadDashboardData();
    }
    
    // Load data if on predictions page
    if (window.location.pathname.includes('predictions.html')) {
        loadPredictions();
    }
    
    // Load data if on trading page
    if (window.location.pathname.includes('trading.html')) {
        loadTradingData();
    }
    
    // Load data if on analytics page
    if (window.location.pathname.includes('analytics.html')) {
        loadAnalyticsData();
    }
});

// Authentication check
function checkAuth() {
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user'));
    
    // If not on login or register page, redirect to login if not authenticated
    if (!window.location.pathname.includes('login.html') && !window.location.pathname.includes('register.html')) {
        if (!token) {
            window.location.href = 'login.html';
            return;
        }
        
        // Update UI with user info
        if (user) {
            const usernameElements = document.querySelectorAll('#username');
            usernameElements.forEach(el => {
                el.textContent = user.username;
            });
            
            const welcomeUsernameElements = document.querySelectorAll('#welcome-username');
            welcomeUsernameElements.forEach(el => {
                el.textContent = user.firstName || user.username;
            });
        }
    }
}

// API client initialization
function initApiClient() {
    window.apiClient = {
        baseUrl: '/api',
        
        async request(endpoint, options = {}) {
            const token = localStorage.getItem('token');
            
            const defaultOptions = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': token ? `Bearer ${token}` : ''
                }
            };
            
            const fetchOptions = {
                ...defaultOptions,
                ...options,
                headers: {
                    ...defaultOptions.headers,
                    ...(options.headers || {})
                }
            };
            
            try {
                const response = await fetch(`${this.baseUrl}${endpoint}`, fetchOptions);
                
                // Handle unauthorized (token expired)
                if (response.status === 401) {
                    localStorage.removeItem('token');
                    localStorage.removeItem('user');
                    window.location.href = 'login.html';
                    return null;
                }
                
                const data = await response.json();
                
                if (!response.ok) {
                    throw new Error(data.message || 'API request failed');
                }
                
                return data;
            } catch (error) {
                console.error('API request error:', error);
                showNotification(error.message || 'An error occurred', 'error');
                return null;
            }
        },
        
        // Auth endpoints
        async login(username, password) {
            return this.request('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ username, password })
            });
        },
        
        async register(userData) {
            return this.request('/auth/register', {
                method: 'POST',
                body: JSON.stringify(userData)
            });
        },
        
        // User endpoints
        async getUserProfile() {
            return this.request('/user/profile');
        },
        
        async updateUserProfile(profileData) {
            return this.request('/user/profile', {
                method: 'PUT',
                body: JSON.stringify(profileData)
            });
        },
        
        // Portfolio endpoints
        async getPortfolios() {
            return this.request('/portfolios');
        },
        
        async getPortfolio(id) {
            return this.request(`/portfolios/${id}`);
        },
        
        async createPortfolio(portfolioData) {
            return this.request('/portfolios', {
                method: 'POST',
                body: JSON.stringify(portfolioData)
            });
        },
        
        // Trade endpoints
        async getTrades(params = {}) {
            const queryString = new URLSearchParams(params).toString();
            return this.request(`/trades?${queryString}`);
        },
        
        async createTrade(tradeData) {
            return this.request('/trades', {
                method: 'POST',
                body: JSON.stringify(tradeData)
            });
        },
        
        // Prediction endpoints
        async getPredictions(params = {}) {
            const queryString = new URLSearchParams(params).toString();
            return this.request(`/predictions?${queryString}`);
        },
        
        async generatePredictions() {
            return this.request('/predictions/generate', {
                method: 'POST'
            });
        }
    };
}

// Load dashboard data
async function loadDashboardData() {
    try {
        // Get portfolios
        const portfolios = await window.apiClient.getPortfolios();
        if (portfolios && portfolios.length > 0) {
            updatePortfolioStats(portfolios[0]);
            updatePositionsTable(portfolios[0].positions);
        }
        
        // Get trades
        const trades = await window.apiClient.getTrades({ limit: 4 });
        if (trades) {
            updateTradesTable(trades);
        }
        
        // Get predictions
        const predictions = await window.apiClient.getPredictions({ limit: 2 });
        if (predictions && predictions.length > 0) {
            updatePredictionsContainer(predictions);
        } else {
            // Generate predictions if none exist
            await window.apiClient.generatePredictions();
            const newPredictions = await window.apiClient.getPredictions({ limit: 2 });
            if (newPredictions) {
                updatePredictionsContainer(newPredictions);
            }
        }
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showNotification('Failed to load dashboard data', 'error');
    }
}

// Update portfolio stats
function updatePortfolioStats(portfolio) {
    if (!portfolio) return;
    
    // Update portfolio value
    const portfolioValueElements = document.querySelectorAll('.stat-value:nth-child(1)');
    portfolioValueElements.forEach(el => {
        el.textContent = `$${portfolio.equity.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    });
    
    // Update portfolio change
    const portfolioChangeElements = document.querySelectorAll('.stat-change:nth-child(2)');
    if (portfolio.performance && portfolioChangeElements) {
        portfolioChangeElements.forEach(el => {
            const changeValue = portfolio.performance.dailyReturn || 0;
            const changePercent = portfolio.performance.dailyReturnPercent || 0;
            
            el.textContent = `${changeValue >= 0 ? '+' : ''}$${Math.abs(changeValue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${changePercent.toFixed(2)}%)`;
            
            if (changeValue >= 0) {
                el.classList.add('positive');
                el.classList.remove('negative');
            } else {
                el.classList.add('negative');
                el.classList.remove('positive');
            }
        });
    }
    
    // Update open positions count
    const positionsCountElements = document.querySelectorAll('.stat-value:nth-child(3)');
    if (positionsCountElements) {
        const positionsCount = portfolio.positions ? portfolio.positions.length : 0;
        positionsCountElements.forEach(el => {
            el.textContent = positionsCount;
        });
    }
    
    // Update positions value
    const positionsValueElements = document.querySelectorAll('.stat-change:nth-child(4)');
    if (positionsValueElements) {
        const positionsValue = portfolio.positions ? portfolio.positions.reduce((sum, pos) => sum + pos.value, 0) : 0;
        positionsValueElements.forEach(el => {
            el.textContent = `Total Value: $${positionsValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        });
    }
}

// Update positions table
function updatePositionsTable(positions) {
    const tableBody = document.getElementById('positions-table-body');
    if (!tableBody || !positions) return;
    
    tableBody.innerHTML = '';
    
    positions.forEach(position => {
        const row = document.createElement('tr');
        
        const plValue = position.unrealizedPL;
        const plPercent = position.unrealizedPLPercent;
        const plClass = plValue >= 0 ? 'positive' : 'negative';
        
        row.innerHTML = `
            <td>${position.symbol}</td>
            <td>${position.quantity}</td>
            <td>$${position.entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            <td>$${position.currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            <td class="${plClass}">${plValue >= 0 ? '+' : ''}$${Math.abs(plValue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${plPercent.toFixed(2)}%)</td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // Add empty state if no positions
    if (positions.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="5" style="text-align: center;">No open positions</td>
        `;
        tableBody.appendChild(row);
    }
}

// Update trades table
function updateTradesTable(trades) {
    const tableBody = document.getElementById('trades-table-body');
    if (!tableBody || !trades) return;
    
    tableBody.innerHTML = '';
    
    trades.forEach(trade => {
        const row = document.createElement('tr');
        
        const date = new Date(trade.createdAt);
        const formattedDate = date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        row.innerHTML = `
            <td>${formattedDate}</td>
            <td>${trade.symbol}</td>
            <td>${trade.type}</td>
            <td class="${trade.side === 'buy' ? 'buy-side' : 'sell-side'}">${trade.side.charAt(0).toUpperCase() + trade.side.slice(1)}</td>
            <td>${trade.quantity}</td>
            <td>$${trade.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            <td><span class="status-badge ${trade.status}">${trade.status.charAt(0).toUpperCase() + trade.status.slice(1)}</span></td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // Add empty state if no trades
    if (trades.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="7" style="text-align: center;">No recent trades</td>
        `;
        tableBody.appendChild(row);
    }
}

// Update predictions container
function updatePredictionsContainer(predictions) {
    const container = document.getElementById('predictions-container');
    if (!container || !predictions) return;
    
    container.innerHTML = '';
    
    predictions.forEach(prediction => {
        const card = document.createElement('div');
        card.className = `prediction-card ${prediction.signal}`;
        
        const potential = prediction.potential;
        const potentialClass = prediction.signal === 'buy' ? 'positive' : 'negative';
        
        card.innerHTML = `
            <div class="prediction-header">
                <div class="symbol-info">
                    <h3>${prediction.symbol}</h3>
                    <p>${getCompanyName(prediction.symbol)}</p>
                </div>
                <div class="signal-badge ${prediction.signal}">${prediction.signal.toUpperCase()}</div>
            </div>
            <div class="prediction-details">
                <div class="prediction-item">
                    <span class="label">Current Price</span>
                    <span class="value">$${prediction.currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div class="prediction-item">
                    <span class="label">Target Price</span>
                    <span class="value">$${prediction.targetPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div class="prediction-item">
                    <span class="label">Potential</span>
                    <span class="value ${potentialClass}">${potential >= 0 ? '+' : ''}${potential.toFixed(2)}%</span>
                </div>
                <div class="prediction-item">
                    <span class="label">Confidence</span>
                    <div class="confidence-bar">
                        <div class="confidence-level" style="width: ${prediction.confidence}%;">${prediction.confidence}%</div>
                    </div>
                </div>
            </div>
            <div class="prediction-footer">
                <span class="timeframe">${prediction.timeframe}</span>
                <button class="action-btn" onclick="tradePrediction('${prediction.symbol}', '${prediction.signal}', ${prediction.currentPrice})">Trade Now</button>
            </div>
        `;
        
        container.appendChild(card);
    });
    
    // Add empty state if no predictions
    if (predictions.length === 0) {
        const emptyState = document.createElement('div');
        emptyState.className = 'empty-state';
        emptyState.innerHTML = `
            <p>No predictions available</p>
            <button class="action-btn" onclick="generatePredictions()">Generate Predictions</button>
        `;
        container.appendChild(emptyState);
    }
}

// Helper function to get company name from symbol
function getCompanyName(symbol) {
    const companies = {
        'AAPL': 'Apple Inc.',
        'MSFT': 'Microsoft Corporation',
        'GOOGL': 'Alphabet Inc.',
        'AMZN': 'Amazon.com, Inc.',
        'META': 'Meta Platforms, Inc.',
        'TSLA': 'Tesla, Inc.',
        'NVDA': 'NVIDIA Corporation'
    };
    
    return companies[symbol] || symbol;
}

// Trade based on prediction
function tradePrediction(symbol, signal, price) {
    // Redirect to trading page with pre-filled values
    window.location.href = `trading.html?symbol=${symbol}&side=${signal === 'buy' ? 'buy' : 'sell'}&price=${price}`;
}

// Generate predictions
async function generatePredictions() {
    try {
        await window.apiClient.generatePredictions();
        showNotification('Predictions generated successfully', 'success');
        
        // Reload predictions
        const predictions = await window.apiClient.getPredictions({ limit: 2 });
        if (predictions) {
            updatePredictionsContainer(predictions);
        }
    } catch (error) {
        console.error('Error generating predictions:', error);
        showNotification('Failed to generate predictions', 'error');
    }
}

// Show notification
function showNotification(message, type = 'info') {
    // Check if notification container exists, create if not
    let notificationContainer = document.querySelector('.notification-container');
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.className = 'notification-container';
        document.body.appendChild(notificationContainer);
        
        // Add styles if not already in CSS
        const style = document.createElement('style');
        style.textContent = `
            .notification-container {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 9999;
            }
            
            .notification {
                background-color: white;
                color: #333;
                border-radius: 4px;
                padding: 15px 20px;
                margin-bottom: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                display: flex;
                align-items: center;
                min-width: 300px;
                max-width: 400px;
                animation: slideIn 0.3s ease-out forwards;
            }
            
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            .notification.success {
                border-left: 4px solid #4CAF50;
            }
            
            .notification.error {
                border-left: 4px solid #F44336;
            }
            
            .notification.info {
                border-left: 4px solid #2196F3;
            }
            
            .notification-icon {
                margin-right: 15px;
                font-size: 20px;
            }
            
            .notification.success .notification-icon {
                color: #4CAF50;
            }
            
            .notification.error .notification-icon {
                color: #F44336;
            }
            
            .notification.info .notification-icon {
                color: #2196F3;
            }
            
            .notification-content {
                flex: 1;
            }
            
            .notification-close {
                color: #aaa;
                font-weight: bold;
                cursor: pointer;
                margin-left: 10px;
            }
            
            .notification-close:hover {
                color: #333;
            }
            
            body.dark-mode .notification {
                background-color: #1E1E1E;
                color: white;
            }
            
            body.dark-mode .notification-close {
                color: #ccc;
            }
            
            body.dark-mode .notification-close:hover {
                color: white;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    // Icon based on type
    let icon;
    switch (type) {
        case 'success':
            icon = 'fas fa-check-circle';
            break;
        case 'error':
            icon = 'fas fa-exclamation-circle';
            break;
        default:
            icon = 'fas fa-info-circle';
    }
    
    notification.innerHTML = `
        <div class="notification-icon">
            <i class="${icon}"></i>
        </div>
        <div class="notification-content">
            ${message}
        </div>
        <div class="notification-close">&times;</div>
    `;
    
    // Add to container
    notificationContainer.appendChild(notification);
    
    // Add close functionality
    const closeButton = notification.querySelector('.notification-close');
    closeButton.addEventListener('click', () => {
        notification.style.opacity = '0';
        setTimeout(() => {
            notification.remove();
        }, 300);
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.opacity = '0';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, 5000);
}

// Login functionality
function login() {
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    if (!usernameInput || !passwordInput) return;
    
    const username = usernameInput.value.trim();
    const password = passwordInput.value;
    
    if (!username || !password) {
        showNotification('Please enter both username and password', 'error');
        return;
    }
    
    // Disable login button
    const loginButton = document.querySelector('.auth-btn');
    if (loginButton) {
        loginButton.disabled = true;
        loginButton.textContent = 'Logging in...';
    }
    
    // Call API
    window.apiClient.login(username, password)
        .then(data => {
            if (data && data.token) {
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));
                window.location.href = 'index.html';
            }
        })
        .catch(error => {
            console.error('Login error:', error);
            showNotification('Login failed. Please check your credentials.', 'error');
        })
        .finally(() => {
            // Re-enable login button
            if (loginButton) {
                loginButton.disabled = false;
                loginButton.textContent = 'Login';
            }
        });
}

// Register functionality
function register() {
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm-password');
    const firstNameInput = document.getElementById('first-name');
    const lastNameInput = document.getElementById('last-name');
    
    if (!usernameInput || !emailInput || !passwordInput || !confirmPasswordInput) return;
    
    const username = usernameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;
    const firstName = firstNameInput ? firstNameInput.value.trim() : '';
    const lastName = lastNameInput ? lastNameInput.value.trim() : '';
    
    if (!username || !email || !password || !confirmPassword) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    // Disable register button
    const registerButton = document.querySelector('.auth-btn');
    if (registerButton) {
        registerButton.disabled = true;
        registerButton.textContent = 'Registering...';
    }
    
    // Call API
    window.apiClient.register({ username, email, password, firstName, lastName })
        .then(data => {
            if (data && data.token) {
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));
                window.location.href = 'index.html';
            }
        })
        .catch(error => {
            console.error('Registration error:', error);
            showNotification('Registration failed. Please try again.', 'error');
        })
        .finally(() => {
            // Re-enable register button
            if (registerButton) {
                registerButton.disabled = false;
                registerButton.textContent = 'Register';
            }
        });
}

// Logout functionality
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}
